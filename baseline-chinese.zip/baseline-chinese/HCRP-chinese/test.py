# 虚拟环境中，进入python环境
import torch

# cuda是否可用
print(torch.cuda.is_available())

# cuda版本
print(torch.version.cuda)

# cudnn版本
print(torch.backends.cudnn.version())
